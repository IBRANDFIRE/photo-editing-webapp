import React, { useState } from "react";
import { HslChannel, HslGrading, DEFAULT_HSL_GRADING } from "../types";

interface HslEditorProps {
  hsl: HslGrading;
  onChange: (hsl: HslGrading) => void;
}

const CHANNELS: { id: HslChannel; name: string; color: string; bg: string }[] = [
  { id: "red", name: "Red", color: "#ef4444", bg: "bg-red-500" },
  { id: "orange", name: "Orange", color: "#f97316", bg: "bg-orange-500" },
  { id: "yellow", name: "Yellow", color: "#eab308", bg: "bg-yellow-500" },
  { id: "green", name: "Green", color: "#10b981", bg: "bg-emerald-500" },
  { id: "aqua", name: "Aqua", color: "#06b6d4", bg: "bg-cyan-500" },
  { id: "blue", name: "Blue", color: "#3b82f6", bg: "bg-blue-500" },
  { id: "purple", name: "Purple", color: "#a855f7", bg: "bg-purple-500" },
  { id: "magenta", name: "Magenta", color: "#ec4899", bg: "bg-pink-500" },
];

export const HslEditor: React.FC<HslEditorProps> = ({ hsl, onChange }) => {
  const [selectedChannel, setSelectedChannel] = useState<HslChannel>("red");
  const [mode, setMode] = useState<"hue" | "sat" | "lum" | "all">("all");

  const currentValues = hsl[selectedChannel];

  const updateChannel = (
    field: "hue" | "saturation" | "lightness",
    val: number
  ) => {
    onChange({
      ...hsl,
      [selectedChannel]: {
        ...hsl[selectedChannel],
        [field]: val,
      },
    });
  };

  const resetCurrent = () => {
    onChange({
      ...hsl,
      [selectedChannel]: { hue: 0, saturation: 0, lightness: 0 },
    });
  };

  const resetAll = () => {
    onChange(DEFAULT_HSL_GRADING);
  };

  const activeMeta = CHANNELS.find((c) => c.id === selectedChannel)!;

  return (
    <div className="space-y-4">
      {/* Channel Swatches */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none">
          {CHANNELS.map((ch) => {
            const hasModifications =
              hsl[ch.id].hue !== 0 ||
              hsl[ch.id].saturation !== 0 ||
              hsl[ch.id].lightness !== 0;

            const isSelected = selectedChannel === ch.id;

            return (
              <button
                key={ch.id}
                type="button"
                onClick={() => setSelectedChannel(ch.id)}
                title={ch.name}
                className={`relative flex flex-col items-center gap-1 p-1.5 rounded-xl transition ${
                  isSelected
                    ? "bg-zinc-800 scale-105 shadow-md ring-2 ring-zinc-500"
                    : "hover:bg-zinc-900/80"
                }`}
              >
                <div
                  className="w-6 h-6 rounded-full shadow-sm flex items-center justify-center"
                  style={{ backgroundColor: ch.color }}
                >
                  {hasModifications && (
                    <div className="w-1.5 h-1.5 rounded-full bg-white shadow-xs" />
                  )}
                </div>
                <span className="text-[10px] font-medium text-zinc-400">
                  {ch.name.slice(0, 3)}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex gap-1">
          <button
            type="button"
            onClick={resetCurrent}
            className="text-xs text-zinc-400 hover:text-white px-2 py-1 rounded-lg bg-zinc-900 border border-zinc-800 transition"
          >
            Reset
          </button>
          <button
            type="button"
            onClick={resetAll}
            className="text-xs text-zinc-400 hover:text-white px-2 py-1 rounded-lg bg-zinc-900 border border-zinc-800 transition"
          >
            All
          </button>
        </div>
      </div>

      {/* Active Channel Sliders */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800/60 pb-2.5">
          <div className="flex items-center gap-2">
            <div
              className="w-3.5 h-3.5 rounded-full shadow-xs"
              style={{ backgroundColor: activeMeta.color }}
            />
            <span className="font-semibold text-sm text-zinc-200">
              {activeMeta.name} Channel
            </span>
          </div>
          <span className="text-xs text-zinc-500">Fine-tune individual colors</span>
        </div>

        {/* Hue Shift */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-300">Hue Shift</span>
            <button
              type="button"
              onClick={() => updateChannel("hue", 0)}
              className="font-mono text-zinc-400 hover:text-zinc-200"
            >
              {currentValues.hue > 0 ? `+${currentValues.hue}` : currentValues.hue}
            </button>
          </div>
          <input
            type="range"
            min="-100"
            max="100"
            value={currentValues.hue}
            onChange={(e) => updateChannel("hue", parseInt(e.target.value, 10))}
            className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>

        {/* Saturation */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-300">Saturation</span>
            <button
              type="button"
              onClick={() => updateChannel("saturation", 0)}
              className="font-mono text-zinc-400 hover:text-zinc-200"
            >
              {currentValues.saturation > 0
                ? `+${currentValues.saturation}`
                : currentValues.saturation}
            </button>
          </div>
          <input
            type="range"
            min="-100"
            max="100"
            value={currentValues.saturation}
            onChange={(e) =>
              updateChannel("saturation", parseInt(e.target.value, 10))
            }
            className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>

        {/* Lightness */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-zinc-300">Luminance</span>
            <button
              type="button"
              onClick={() => updateChannel("lightness", 0)}
              className="font-mono text-zinc-400 hover:text-zinc-200"
            >
              {currentValues.lightness > 0
                ? `+${currentValues.lightness}`
                : currentValues.lightness}
            </button>
          </div>
          <input
            type="range"
            min="-100"
            max="100"
            value={currentValues.lightness}
            onChange={(e) =>
              updateChannel("lightness", parseInt(e.target.value, 10))
            }
            className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>
      </div>
    </div>
  );
};
