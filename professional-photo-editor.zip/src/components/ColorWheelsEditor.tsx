import React, { useRef, useState } from "react";
import { ColorGrading, ColorWheelValue, DEFAULT_COLOR_GRADING } from "../types";
import { hslToRgb } from "../utils/imageProcessing";

interface ColorWheelsEditorProps {
  colorGrading: ColorGrading;
  onChange: (grading: ColorGrading) => void;
}

type WheelKey = "shadows" | "midtones" | "highlights";

interface SingleWheelProps {
  label: string;
  value: ColorWheelValue;
  onChange: (val: ColorWheelValue) => void;
}

const SingleWheel: React.FC<SingleWheelProps> = ({ label, value, onChange }) => {
  const wheelRef = useRef<HTMLDivElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Wheel size
  const size = 130;
  const radius = size / 2;

  // Calculate puck position from hue & saturation
  const rad = (value.hue * Math.PI) / 180;
  const dist = (value.saturation / 100) * (radius - 10);
  const puckX = radius + dist * Math.cos(rad);
  const puckY = radius + dist * Math.sin(rad);

  const updateFromCoords = (clientX: number, clientY: number) => {
    if (!wheelRef.current) return;
    const rect = wheelRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = clientX - cx;
    const dy = clientY - cy;

    let angle = (Math.atan2(dy, dx) * 180) / Math.PI;
    if (angle < 0) angle += 360;

    const currentDist = Math.hypot(dx, dy);
    const maxDist = rect.width / 2 - 8;
    const sat = Math.min(100, Math.round((currentDist / maxDist) * 100));

    onChange({
      ...value,
      hue: Math.round(angle),
      saturation: sat,
    });
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    setIsDragging(true);
    updateFromCoords(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    updateFromCoords(e.clientX, e.clientY);
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  const handleReset = () => {
    onChange({ hue: 0, saturation: 0, luminance: 0 });
  };

  // Puck color
  const [pr, pg, pb] = hslToRgb(value.hue, value.saturation / 100, 0.5);
  const puckColor = `rgb(${pr}, ${pg}, ${pb})`;

  return (
    <div className="flex flex-col items-center bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-3 flex-1 min-w-[140px]">
      <div className="flex items-center justify-between w-full mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-zinc-300">
          {label}
        </span>
        <button
          type="button"
          onClick={handleReset}
          className="text-[10px] text-zinc-500 hover:text-zinc-300 transition"
        >
          Reset
        </button>
      </div>

      {/* Color Wheel Disc */}
      <div
        ref={wheelRef}
        className="relative w-[130px] h-[130px] rounded-full border border-zinc-700/60 cursor-crosshair touch-none select-none shadow-inner"
        style={{
          background:
            "radial-gradient(circle at center, #71717a 0%, transparent 70%), conic-gradient(from 0deg, #f43f5e, #f59e0b, #eab308, #10b981, #06b6d4, #3b82f6, #a855f7, #ec4899, #f43f5e)",
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
      >
        {/* Crosshair guidelines */}
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-px bg-white/20 pointer-events-none" />
        <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-px bg-white/20 pointer-events-none" />
        <div className="absolute inset-2 rounded-full border border-white/10 pointer-events-none" />

        {/* Puck */}
        <div
          className="absolute w-5 h-5 rounded-full border-2 border-white shadow-md -translate-x-1/2 -translate-y-1/2 pointer-events-none transition-transform"
          style={{
            left: `${puckX}px`,
            top: `${puckY}px`,
            backgroundColor: value.saturation > 5 ? puckColor : "#ffffff",
          }}
        />
      </div>

      {/* Numeric Indicator */}
      <div className="flex items-center justify-between w-full text-[10px] text-zinc-400 font-mono mt-2 mb-1 px-1">
        <span>H: {value.hue}°</span>
        <span>S: {value.saturation}%</span>
        <span>L: {value.luminance}</span>
      </div>

      {/* Luminance Slider */}
      <div className="w-full space-y-1 mt-1">
        <div className="flex items-center justify-between text-[10px] text-zinc-400">
          <span>Luminance</span>
          <button
            type="button"
            onClick={() => onChange({ ...value, luminance: 0 })}
            className="hover:text-zinc-200"
          >
            {value.luminance > 0 ? `+${value.luminance}` : value.luminance}
          </button>
        </div>
        <input
          type="range"
          min="-100"
          max="100"
          value={value.luminance}
          onChange={(e) =>
            onChange({ ...value, luminance: parseInt(e.target.value, 10) })
          }
          className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
        />
      </div>
    </div>
  );
};

export const ColorWheelsEditor: React.FC<ColorWheelsEditorProps> = ({
  colorGrading,
  onChange,
}) => {
  const [activeTab, setActiveTab] = useState<"all" | WheelKey>("all");

  const updateWheel = (key: WheelKey, val: ColorWheelValue) => {
    onChange({
      ...colorGrading,
      [key]: val,
    });
  };

  const handleResetAll = () => {
    onChange(DEFAULT_COLOR_GRADING);
  };

  return (
    <div className="space-y-4">
      {/* Header & Mode Selector */}
      <div className="flex items-center justify-between">
        <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab("all")}
            className={`px-3 py-1 font-semibold rounded-lg transition ${
              activeTab === "all"
                ? "bg-zinc-800 text-white"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            3-Way
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("shadows")}
            className={`px-3 py-1 font-semibold rounded-lg transition ${
              activeTab === "shadows"
                ? "bg-zinc-800 text-white"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Shadows
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("midtones")}
            className={`px-3 py-1 font-semibold rounded-lg transition ${
              activeTab === "midtones"
                ? "bg-zinc-800 text-white"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Midtones
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("highlights")}
            className={`px-3 py-1 font-semibold rounded-lg transition ${
              activeTab === "highlights"
                ? "bg-zinc-800 text-white"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Highlights
          </button>
        </div>

        <button
          type="button"
          onClick={handleResetAll}
          className="text-xs text-zinc-400 hover:text-white px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 transition"
        >
          Reset Grading
        </button>
      </div>

      {/* Wheels display */}
      {activeTab === "all" ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <SingleWheel
            label="Shadows"
            value={colorGrading.shadows}
            onChange={(val) => updateWheel("shadows", val)}
          />
          <SingleWheel
            label="Midtones"
            value={colorGrading.midtones}
            onChange={(val) => updateWheel("midtones", val)}
          />
          <SingleWheel
            label="Highlights"
            value={colorGrading.highlights}
            onChange={(val) => updateWheel("highlights", val)}
          />
        </div>
      ) : (
        <div className="max-w-[240px] mx-auto">
          <SingleWheel
            label={activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            value={colorGrading[activeTab]}
            onChange={(val) => updateWheel(activeTab, val)}
          />
        </div>
      )}

      {/* Blending & Balance Controls */}
      <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-3.5 space-y-3">
        <div>
          <div className="flex items-center justify-between text-xs text-zinc-300 mb-1">
            <span>Blending (Tonal overlap)</span>
            <span className="font-mono text-zinc-400">{colorGrading.blending}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={colorGrading.blending}
            onChange={(e) =>
              onChange({
                ...colorGrading,
                blending: parseInt(e.target.value, 10),
              })
            }
            className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>

        <div>
          <div className="flex items-center justify-between text-xs text-zinc-300 mb-1">
            <span>Balance (Shadow vs Highlight bias)</span>
            <span className="font-mono text-zinc-400">
              {colorGrading.balance > 0
                ? `+${colorGrading.balance}`
                : colorGrading.balance}
            </span>
          </div>
          <input
            type="range"
            min="-100"
            max="100"
            value={colorGrading.balance}
            onChange={(e) =>
              onChange({
                ...colorGrading,
                balance: parseInt(e.target.value, 10),
              })
            }
            className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>
      </div>
    </div>
  );
};
