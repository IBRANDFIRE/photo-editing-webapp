import React, { useMemo, useState } from "react";
import { HistogramData } from "../utils/imageProcessing";

interface HistogramProps {
  data: HistogramData;
}

export const Histogram: React.FC<HistogramProps> = ({ data }) => {
  const [channel, setChannel] = useState<"all" | "lum" | "r" | "g" | "b">("all");

  const { maxVal, paths } = useMemo(() => {
    // Find peak value across 256 bins to normalize height
    let max = 1;
    for (let i = 1; i < 255; i++) {
      if (data.lum[i] > max) max = data.lum[i];
      if (data.r[i] > max) max = data.r[i];
      if (data.g[i] > max) max = data.g[i];
      if (data.b[i] > max) max = data.b[i];
    }

    const svgW = 256;
    const svgH = 64;

    const makePath = (bins: number[]) => {
      let d = `M 0 ${svgH}`;
      for (let x = 0; x < 256; x++) {
        const y = svgH - (bins[x] / max) * svgH * 0.92;
        d += ` L ${x} ${Math.max(2, y)}`;
      }
      d += ` L 255 ${svgH} Z`;
      return d;
    };

    return {
      maxVal: max,
      paths: {
        r: makePath(data.r),
        g: makePath(data.g),
        b: makePath(data.b),
        lum: makePath(data.lum),
      },
    };
  }, [data]);

  return (
    <div
      id="histogram-container"
      className="bg-zinc-900/90 backdrop-blur-md rounded-xl p-2.5 border border-zinc-800/80 shadow-lg text-xs"
    >
      <div className="flex items-center justify-between mb-1.5 px-0.5">
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[10px] uppercase tracking-wider text-zinc-400 font-semibold">
            Histogram
          </span>
          {data.shadowClipping && (
            <span
              title="Shadow clipping detected"
              className="inline-block w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"
            />
          )}
          {data.highlightClipping && (
            <span
              title="Highlight clipping detected"
              className="inline-block w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"
            />
          )}
        </div>

        {/* Channel selector */}
        <div className="flex items-center gap-1 bg-zinc-800/80 rounded-md p-0.5 text-[10px]">
          <button
            type="button"
            onClick={() => setChannel("all")}
            className={`px-1.5 py-0.5 rounded transition ${
              channel === "all"
                ? "bg-zinc-700 text-white font-medium"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            RGB
          </button>
          <button
            type="button"
            onClick={() => setChannel("lum")}
            className={`px-1.5 py-0.5 rounded transition ${
              channel === "lum"
                ? "bg-zinc-700 text-white font-medium"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            Lum
          </button>
          <button
            type="button"
            onClick={() => setChannel("r")}
            className={`px-1.5 py-0.5 rounded transition ${
              channel === "r"
                ? "bg-red-950/80 text-red-300 font-medium"
                : "text-zinc-400 hover:text-red-400"
            }`}
          >
            R
          </button>
          <button
            type="button"
            onClick={() => setChannel("g")}
            className={`px-1.5 py-0.5 rounded transition ${
              channel === "g"
                ? "bg-emerald-950/80 text-emerald-300 font-medium"
                : "text-zinc-400 hover:text-emerald-400"
            }`}
          >
            G
          </button>
          <button
            type="button"
            onClick={() => setChannel("b")}
            className={`px-1.5 py-0.5 rounded transition ${
              channel === "b"
                ? "bg-blue-950/80 text-blue-300 font-medium"
                : "text-zinc-400 hover:text-blue-400"
            }`}
          >
            B
          </button>
        </div>
      </div>

      <div className="relative w-full h-14 bg-zinc-950/70 rounded-lg overflow-hidden border border-zinc-800/50">
        <svg
          viewBox="0 0 256 64"
          preserveAspectRatio="none"
          className="w-full h-full"
        >
          {/* Grid lines */}
          <line
            x1="64"
            y1="0"
            x2="64"
            y2="64"
            stroke="#27272a"
            strokeDasharray="2 2"
          />
          <line
            x1="128"
            y1="0"
            x2="128"
            y2="64"
            stroke="#27272a"
            strokeDasharray="2 2"
          />
          <line
            x1="192"
            y1="0"
            x2="192"
            y2="64"
            stroke="#27272a"
            strokeDasharray="2 2"
          />

          {/* Curves */}
          {channel === "all" && (
            <>
              <path
                d={paths.r}
                fill="rgba(239, 68, 68, 0.2)"
                stroke="#ef4444"
                strokeWidth="1.2"
                style={{ mixBlendMode: "screen" }}
              />
              <path
                d={paths.g}
                fill="rgba(16, 185, 129, 0.2)"
                stroke="#10b981"
                strokeWidth="1.2"
                style={{ mixBlendMode: "screen" }}
              />
              <path
                d={paths.b}
                fill="rgba(59, 130, 246, 0.2)"
                stroke="#3b82f6"
                strokeWidth="1.2"
                style={{ mixBlendMode: "screen" }}
              />
            </>
          )}

          {channel === "lum" && (
            <path
              d={paths.lum}
              fill="rgba(244, 244, 245, 0.2)"
              stroke="#e4e4e7"
              strokeWidth="1.5"
            />
          )}

          {channel === "r" && (
            <path
              d={paths.r}
              fill="rgba(239, 68, 68, 0.25)"
              stroke="#ef4444"
              strokeWidth="1.5"
            />
          )}

          {channel === "g" && (
            <path
              d={paths.g}
              fill="rgba(16, 185, 129, 0.25)"
              stroke="#10b981"
              strokeWidth="1.5"
            />
          )}

          {channel === "b" && (
            <path
              d={paths.b}
              fill="rgba(59, 130, 246, 0.25)"
              stroke="#3b82f6"
              strokeWidth="1.5"
            />
          )}
        </svg>

        {/* Shadow & Highlight clipping indicators overlay */}
        <div className="absolute inset-x-0 bottom-0 px-1 py-0.5 flex justify-between text-[9px] text-zinc-500 font-mono pointer-events-none">
          <span>0 (Shadows)</span>
          <span>128 (Mids)</span>
          <span>255 (Highlights)</span>
        </div>
      </div>
    </div>
  );
};
