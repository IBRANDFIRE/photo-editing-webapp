import React, { useRef, useState } from "react";
import { CurvePoint, ToneCurves, DEFAULT_CURVES } from "../types";
import { buildCurveLut } from "../utils/imageProcessing";

interface ToneCurveEditorProps {
  curves: ToneCurves;
  onChange: (curves: ToneCurves) => void;
}

type ChannelKey = "rgb" | "red" | "green" | "blue";

export const ToneCurveEditor: React.FC<ToneCurveEditorProps> = ({
  curves,
  onChange,
}) => {
  const [activeChannel, setActiveChannel] = useState<ChannelKey>("rgb");
  const [draggingIndex, setDraggingIndex] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const currentPoints = curves[activeChannel];
  const lut = buildCurveLut(currentPoints);

  // Convert normalized 0..255 coordinates to SVG 0..200 viewBox
  const toSvgX = (x: number) => (x / 255) * 200;
  const toSvgY = (y: number) => 200 - (y / 255) * 200;

  // Convert SVG coordinates to 0..255
  const fromSvgCoords = (clientX: number, clientY: number) => {
    if (!svgRef.current) return { x: 0, y: 0 };
    const rect = svgRef.current.getBoundingClientRect();
    const nx = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    const ny = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));
    return {
      x: Math.round(nx * 255),
      y: Math.round((1 - ny) * 255),
    };
  };

  // Build SVG path from LUT
  let curvePath = `M 0 ${toSvgY(lut[0])}`;
  for (let x = 1; x < 256; x += 2) {
    curvePath += ` L ${toSvgX(x)} ${toSvgY(lut[x])}`;
  }

  // Channel theme colors
  const channelColors: Record<
    ChannelKey,
    { line: string; bg: string; dot: string; label: string }
  > = {
    rgb: {
      line: "#f4f4f5",
      bg: "rgba(244, 244, 245, 0.08)",
      dot: "#ffffff",
      label: "RGB",
    },
    red: {
      line: "#ef4444",
      bg: "rgba(239, 68, 68, 0.12)",
      dot: "#f87171",
      label: "Red",
    },
    green: {
      line: "#10b981",
      bg: "rgba(16, 185, 129, 0.12)",
      dot: "#34d399",
      label: "Green",
    },
    blue: {
      line: "#3b82f6",
      bg: "rgba(59, 130, 246, 0.12)",
      dot: "#60a5fa",
      label: "Blue",
    },
  };

  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    e.preventDefault();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    const { x, y } = fromSvgCoords(e.clientX, e.clientY);

    // Check if clicked close to an existing point
    let foundIdx = -1;
    for (let i = 0; i < currentPoints.length; i++) {
      const pt = currentPoints[i];
      const dist = Math.hypot(pt.x - x, pt.y - y);
      if (dist < 18) {
        foundIdx = i;
        break;
      }
    }

    if (foundIdx !== -1) {
      setDraggingIndex(foundIdx);
    } else {
      // Add new point (up to 8 points)
      if (currentPoints.length < 8) {
        const newPoints = [...currentPoints, { x, y }].sort((a, b) => a.x - b.x);
        onChange({
          ...curves,
          [activeChannel]: newPoints,
        });
        const newIdx = newPoints.findIndex((p) => p.x === x && p.y === y);
        setDraggingIndex(newIdx);
      }
    }
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (draggingIndex === null) return;
    const { x, y } = fromSvgCoords(e.clientX, e.clientY);

    const updated = [...currentPoints];
    const pt = updated[draggingIndex];

    // End points: keep x = 0 or x = 255 fixed, but allow y to move
    if (draggingIndex === 0) {
      pt.y = y;
    } else if (draggingIndex === currentPoints.length - 1) {
      pt.y = y;
    } else {
      // Constrain x between neighbors
      const prevX = updated[draggingIndex - 1].x + 4;
      const nextX = updated[draggingIndex + 1].x - 4;
      pt.x = Math.max(prevX, Math.min(nextX, x));
      pt.y = y;
    }

    onChange({
      ...curves,
      [activeChannel]: updated,
    });
  };

  const handlePointerUp = () => {
    setDraggingIndex(null);
  };

  const handleDoubleClickPoint = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    // Do not remove end points
    if (idx === 0 || idx === currentPoints.length - 1) return;
    const updated = currentPoints.filter((_, i) => i !== idx);
    onChange({
      ...curves,
      [activeChannel]: updated,
    });
  };

  const resetCurrentChannel = () => {
    onChange({
      ...curves,
      [activeChannel]: [
        { x: 0, y: 0 },
        { x: 255, y: 255 },
      ],
    });
  };

  const resetAllChannels = () => {
    onChange(DEFAULT_CURVES);
  };

  return (
    <div className="space-y-4">
      {/* Channel Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800">
          {(["rgb", "red", "green", "blue"] as ChannelKey[]).map((ch) => (
            <button
              key={ch}
              type="button"
              onClick={() => setActiveChannel(ch)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                activeChannel === ch
                  ? "bg-zinc-800 text-white shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              {channelColors[ch].label}
            </button>
          ))}
        </div>

        <div className="flex gap-1.5">
          <button
            type="button"
            onClick={resetCurrentChannel}
            className="text-xs text-zinc-400 hover:text-white px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 transition"
          >
            Reset
          </button>
          <button
            type="button"
            onClick={resetAllChannels}
            className="text-xs text-zinc-400 hover:text-white px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 transition"
          >
            Reset All
          </button>
        </div>
      </div>

      {/* Interactive SVG Curve Canvas */}
      <div className="relative w-full aspect-square max-w-[320px] mx-auto bg-zinc-950 rounded-2xl border border-zinc-800/80 p-3 shadow-inner select-none touch-none">
        <svg
          ref={svgRef}
          viewBox="0 0 200 200"
          className="w-full h-full cursor-crosshair overflow-visible"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
        >
          {/* Grid lines (quarter divisions) */}
          <line x1="50" y1="0" x2="50" y2="200" stroke="#27272a" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="100" y1="0" x2="100" y2="200" stroke="#27272a" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="150" y1="0" x2="150" y2="200" stroke="#27272a" strokeWidth="1" strokeDasharray="2 2" />

          <line x1="0" y1="50" x2="200" y2="50" stroke="#27272a" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="0" y1="100" x2="200" y2="100" stroke="#27272a" strokeWidth="1" strokeDasharray="2 2" />
          <line x1="0" y1="150" x2="200" y2="150" stroke="#27272a" strokeWidth="1" strokeDasharray="2 2" />

          {/* Neutral 45-degree diagonal reference */}
          <line x1="0" y1="200" x2="200" y2="0" stroke="#3f3f46" strokeWidth="1" strokeDasharray="3 3" />

          {/* Interpolated spline curve line */}
          <path
            d={curvePath}
            fill="none"
            stroke={channelColors[activeChannel].line}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Control Points */}
          {currentPoints.map((pt, i) => (
            <g key={i}>
              <circle
                cx={toSvgX(pt.x)}
                cy={toSvgY(pt.y)}
                r="7"
                fill={channelColors[activeChannel].dot}
                stroke="#18181b"
                strokeWidth="2"
                className="cursor-pointer transition-transform active:scale-125"
                onDoubleClick={(e) => handleDoubleClickPoint(i, e)}
              />
            </g>
          ))}
        </svg>

        <div className="absolute inset-x-3 bottom-1 flex justify-between text-[9px] text-zinc-500 font-mono pointer-events-none">
          <span>Blacks</span>
          <span>Shadows</span>
          <span>Midtones</span>
          <span>Highlights</span>
          <span>Whites</span>
        </div>
      </div>

      <p className="text-center text-[11px] text-zinc-400">
        Tap along curve to add points. Double-tap to delete point. Drag to reshape tone curve.
      </p>
    </div>
  );
};
