import React, { useState } from "react";
import { ExportSettings } from "../types";
import {
  Download,
  X,
  FileImage,
  Check,
  Copy,
  Sparkles,
  ShieldCheck,
} from "lucide-react";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalDimensions: { width: number; height: number };
  onExportDownload: (settings: ExportSettings) => Promise<void>;
  onCopyToClipboard: (settings: ExportSettings) => Promise<boolean>;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  originalDimensions,
  onExportDownload,
  onCopyToClipboard,
}) => {
  const [settings, setSettings] = useState<ExportSettings>({
    format: "jpeg",
    quality: 92,
    scale: 1,
    watermark: false,
    watermarkText: "© Photography",
    filename: `photo-edit-${new Date().toISOString().slice(0, 10)}`,
  });

  const [isExporting, setIsExporting] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const targetWidth = Math.round(originalDimensions.width * settings.scale);
  const targetHeight = Math.round(originalDimensions.height * settings.scale);
  const megapixel = ((targetWidth * targetHeight) / 1_000_000).toFixed(1);

  // Approximate file size estimate based on format, scale, and quality
  const estimateSize = () => {
    const rawBytes = targetWidth * targetHeight * 3;
    let factor = 0.05;
    if (settings.format === "png") {
      factor = 0.35;
    } else if (settings.format === "jpeg") {
      factor = (settings.quality / 100) * 0.12;
    } else if (settings.format === "webp") {
      factor = (settings.quality / 100) * 0.08;
    }
    const bytes = rawBytes * factor;
    if (bytes > 1_000_000) {
      return `~${(bytes / 1_000_000).toFixed(1)} MB`;
    }
    return `~${Math.round(bytes / 1000)} KB`;
  };

  const handleDownload = async () => {
    try {
      setIsExporting(true);
      await onExportDownload(settings);
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleCopy = async () => {
    try {
      const ok = await onCopyToClipboard(settings);
      if (ok) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-zinc-100">
                Export High-Resolution
              </h3>
              <p className="text-[11px] text-zinc-400">
                Master quality photographic render
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live File Spec Card */}
        <div className="p-3.5 bg-zinc-950/80 rounded-2xl border border-zinc-800/80 flex items-center justify-between text-xs">
          <div>
            <span className="text-zinc-500 font-mono text-[10px] uppercase">
              Output Dimensions
            </span>
            <div className="text-zinc-200 font-semibold mt-0.5">
              {targetWidth} × {targetHeight} px
              <span className="text-zinc-400 font-normal ml-1.5">
                ({megapixel} MP)
              </span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-zinc-500 font-mono text-[10px] uppercase">
              Est. File Size
            </span>
            <div className="text-sky-400 font-semibold font-mono mt-0.5">
              {estimateSize()}
            </div>
          </div>
        </div>

        {/* Format Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-zinc-300">Format</label>
          <div className="grid grid-cols-3 gap-2 text-xs">
            {(["jpeg", "png", "webp"] as const).map((fmt) => (
              <button
                key={fmt}
                type="button"
                onClick={() => setSettings({ ...settings, format: fmt })}
                className={`py-2 px-3 rounded-xl border font-semibold uppercase tracking-wider transition ${
                  settings.format === fmt
                    ? "bg-zinc-800 border-sky-500 text-white shadow-xs"
                    : "bg-zinc-950/80 border-zinc-800 text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>
          {settings.format === "png" && (
            <p className="text-[11px] text-zinc-400">
              Lossless with full alpha transparency support (best for background cutouts).
            </p>
          )}
        </div>

        {/* Quality Slider (for JPEG / WEBP) */}
        {settings.format !== "png" && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-zinc-300 font-medium">JPEG Quality</span>
              <span className="font-mono text-zinc-400 font-semibold">
                {settings.quality}%
              </span>
            </div>
            <input
              type="range"
              min="50"
              max="100"
              value={settings.quality}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  quality: parseInt(e.target.value, 10),
                })
              }
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
            />
          </div>
        )}

        {/* Resolution Scale */}
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-zinc-300">
            Resolution Scale
          </label>
          <div className="grid grid-cols-4 gap-2 text-xs">
            {([0.5, 0.75, 1, 2] as const).map((sc) => (
              <button
                key={sc}
                type="button"
                onClick={() => setSettings({ ...settings, scale: sc })}
                className={`py-2 rounded-xl border font-medium transition ${
                  settings.scale === sc
                    ? "bg-zinc-800 border-sky-500 text-white shadow-xs"
                    : "bg-zinc-950/80 border-zinc-800 text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {sc === 1 ? "1x Native" : sc === 2 ? "2x Print" : `${sc * 100}%`}
              </button>
            ))}
          </div>
        </div>

        {/* Watermark toggle */}
        <div className="space-y-2 pt-1 border-t border-zinc-800/60">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-300 font-medium">
              Embed Signature Watermark
            </span>
            <input
              type="checkbox"
              checked={settings.watermark}
              onChange={(e) =>
                setSettings({ ...settings, watermark: e.target.checked })
              }
              className="w-4 h-4 rounded-md border-zinc-700 accent-sky-500 cursor-pointer"
            />
          </div>

          {settings.watermark && (
            <input
              type="text"
              value={settings.watermarkText}
              onChange={(e) =>
                setSettings({ ...settings, watermarkText: e.target.value })
              }
              placeholder="e.g. © 2026 Your Name"
              className="w-full text-xs px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-200 placeholder-zinc-500 focus:outline-hidden focus:border-sky-500"
            />
          )}
        </div>

        {/* Filename */}
        <div className="space-y-1">
          <label className="text-xs font-medium text-zinc-300">File Name</label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={settings.filename}
              onChange={(e) =>
                setSettings({ ...settings, filename: e.target.value })
              }
              className="w-full text-xs px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-200 focus:outline-hidden focus:border-sky-500 font-mono"
            />
            <span className="text-xs font-mono text-zinc-500">
              .{settings.format}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 pt-2">
          <button
            type="button"
            onClick={handleCopy}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700/80 text-zinc-200 hover:text-white text-xs font-medium border border-zinc-700/60 transition"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Copied Image!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Image</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleDownload}
            disabled={isExporting}
            className="flex-2 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold shadow-lg shadow-sky-500/20 transition disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? "Rendering..." : "Download File"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
