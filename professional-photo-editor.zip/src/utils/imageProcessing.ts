import {
  Adjustments,
  ColorGrading,
  CurvePoint,
  HslGrading,
  HslChannel,
  ToneCurves,
  VirtualLight,
  SkyAtmosphere,
} from "../types";

// Helper: clamp number between min and max
export function clamp(val: number, min = 0, max = 255): number {
  return Math.max(min, Math.min(max, val));
}

// RGB to HSL conversion (r, g, b in 0..255; returns h: 0..360, s: 0..1, l: 0..1)
export function rgbToHsl(
  r: number,
  g: number,
  b: number
): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h *= 60;
  }

  return [h, s, l];
}

// Helper for HSL to RGB
function hueToRgb(p: number, q: number, t: number): number {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p + (q - p) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
  return p;
}

// HSL to RGB conversion (h: 0..360, s: 0..1, l: 0..1; returns r, g, b in 0..255)
export function hslToRgb(
  h: number,
  s: number,
  l: number
): [number, number, number] {
  h = ((h % 360) + 360) % 360;
  s = Math.max(0, Math.min(1, s));
  l = Math.max(0, Math.min(1, l));

  if (s === 0) {
    const val = Math.round(l * 255);
    return [val, val, val];
  }

  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const r = Math.round(hueToRgb(p, q, h / 360 + 1 / 3) * 255);
  const g = Math.round(hueToRgb(p, q, h / 360) * 255);
  const b = Math.round(hueToRgb(p, q, h / 360 - 1 / 3) * 255);

  return [r, g, b];
}

// Monotone Cubic Spline Interpolation for Tone Curve LUT
export function buildCurveLut(points: CurvePoint[]): Uint8Array {
  const lut = new Uint8Array(256);
  if (!points || points.length === 0) {
    for (let i = 0; i < 256; i++) lut[i] = i;
    return lut;
  }

  // Sort points by x coordinate
  const sorted = [...points].sort((a, b) => a.x - b.x);

  // Simple Catmull-Rom or piecewise linear with smoothing
  for (let i = 0; i < 256; i++) {
    if (i <= sorted[0].x) {
      lut[i] = clamp(sorted[0].y);
      continue;
    }
    if (i >= sorted[sorted.length - 1].x) {
      lut[i] = clamp(sorted[sorted.length - 1].y);
      continue;
    }

    // Find segment
    let seg = 0;
    while (seg < sorted.length - 1 && sorted[seg + 1].x < i) {
      seg++;
    }

    const p0 = sorted[seg];
    const p1 = sorted[seg + 1];
    const t = (i - p0.x) / (p1.x - p0.x || 1);

    // Smoothstep interpolation
    const smoothT = t * t * (3 - 2 * t);
    const val = p0.y + (p1.y - p0.y) * smoothT;
    lut[i] = clamp(Math.round(val));
  }

  return lut;
}

// Determine which of the 8 HSL channels a given hue (0..360) belongs to, with weights
export function getHslChannelWeights(
  hue: number
): { channel: HslChannel; weight: number }[] {
  // Hue centers in degrees:
  // Red: 0/360, Orange: 30, Yellow: 60, Green: 120, Aqua: 180, Blue: 240, Purple: 280, Magenta: 320
  const centers: { channel: HslChannel; center: number }[] = [
    { channel: "red", center: 0 },
    { channel: "orange", center: 30 },
    { channel: "yellow", center: 60 },
    { channel: "green", center: 120 },
    { channel: "aqua", center: 180 },
    { channel: "blue", center: 240 },
    { channel: "purple", center: 280 },
    { channel: "magenta", center: 320 },
  ];

  const results: { channel: HslChannel; weight: number }[] = [];
  let totalWeight = 0;

  for (const c of centers) {
    let diff = Math.abs(hue - c.center);
    if (diff > 180) diff = 360 - diff;

    // Radius of influence ~ 45 degrees
    if (diff < 45) {
      const w = 1 - diff / 45;
      results.push({ channel: c.channel, weight: w });
      totalWeight += w;
    }
  }

  if (totalWeight > 0) {
    for (const r of results) {
      r.weight /= totalWeight;
    }
  } else {
    results.push({ channel: "red", weight: 1 });
  }

  return results;
}

// Convert degrees to RGB tint offset (for 3-Way Color Wheels)
function wheelToRgbOffset(hue: number, sat: number): [number, number, number] {
  if (sat === 0) return [0, 0, 0];
  const [r, g, b] = hslToRgb(hue, 1, 0.5);
  const factor = (sat / 100) * 0.5;
  return [(r - 128) * factor, (g - 128) * factor, (b - 128) * factor];
}

export interface RenderPipelineOptions {
  adjustments: Adjustments;
  colorGrading: ColorGrading;
  hsl: HslGrading;
  curves: ToneCurves;
  filterIntensity?: number; // 0 to 100
  maskCanvas?: HTMLCanvasElement | null;
  targetMaskLayer?: "all" | "subject" | "background";
  virtualLight?: VirtualLight;
  skyAtmosphere?: SkyAtmosphere;
}

// Master Render Pipeline: transforms source image onto destination canvas
export function applyImagePipeline(
  sourceCanvas: HTMLCanvasElement | HTMLImageElement,
  destCanvas: HTMLCanvasElement,
  options: RenderPipelineOptions
) {
  const width = sourceCanvas.width;
  const height = sourceCanvas.height;

  if (destCanvas.width !== width || destCanvas.height !== height) {
    destCanvas.width = width;
    destCanvas.height = height;
  }

  const destCtx = destCanvas.getContext("2d", { willReadFrequently: true });
  if (!destCtx) return;

  // Draw base source
  destCtx.drawImage(sourceCanvas, 0, 0);

  const imgData = destCtx.getImageData(0, 0, width, height);
  const data = imgData.data;
  const len = data.length;

  const {
    adjustments,
    colorGrading,
    hsl: hslGrading,
    curves,
    filterIntensity = 100,
    maskCanvas,
    targetMaskLayer = "all",
  } = options;

  // Precompute Tone Curve LUTs
  const lutRgb = buildCurveLut(curves.rgb);
  const lutR = buildCurveLut(curves.red);
  const lutG = buildCurveLut(curves.green);
  const lutB = buildCurveLut(curves.blue);

  // Precompute Adjustments parameters
  const expFactor = Math.pow(2, adjustments.exposure);
  const contrastFactor =
    (259 * (adjustments.contrast + 255)) /
    (255 * (259 - adjustments.contrast));
  const tempShift = adjustments.temperature; // -100 to 100
  const tintShift = adjustments.tint;       // -100 to 100
  const highlightsAdj = adjustments.highlights / 100;
  const shadowsAdj = adjustments.shadows / 100;
  const whitesAdj = adjustments.whites / 100;
  const blacksAdj = adjustments.blacks / 100;
  const vibranceAdj = adjustments.vibrance / 100;
  const saturationAdj = adjustments.saturation / 100;

  // Color Wheels offsets
  const shadowsRgb = wheelToRgbOffset(
    colorGrading.shadows.hue,
    colorGrading.shadows.saturation
  );
  const midtonesRgb = wheelToRgbOffset(
    colorGrading.midtones.hue,
    colorGrading.midtones.saturation
  );
  const highlightsRgb = wheelToRgbOffset(
    colorGrading.highlights.hue,
    colorGrading.highlights.saturation
  );

  const shadowsLum = colorGrading.shadows.luminance;
  const midtonesLum = colorGrading.midtones.luminance;
  const highlightsLum = colorGrading.highlights.luminance;
  const balanceOffset = (colorGrading.balance / 100) * 0.25;

  // Optional mask data if target is subject or background
  let maskData: Uint8ClampedArray | null = null;
  if (maskCanvas && targetMaskLayer !== "all") {
    const maskCtx = maskCanvas.getContext("2d", { willReadFrequently: true });
    if (maskCtx) {
      maskData = maskCtx.getImageData(0, 0, width, height).data;
    }
  }

  // Fast pixel loop
  for (let i = 0; i < len; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];

    // Check layer mask if selective masking is on
    let layerWeight = 1.0;
    if (maskData) {
      const maskAlpha = maskData[i + 3] / 255;
      if (targetMaskLayer === "subject") {
        layerWeight = maskAlpha;
      } else if (targetMaskLayer === "background") {
        layerWeight = 1.0 - maskAlpha;
      }
      if (layerWeight <= 0.01) continue;
    }

    const origR = r;
    const origG = g;
    const origB = b;

    // 1. White balance (Temp & Tint)
    if (tempShift !== 0 || tintShift !== 0) {
      r += tempShift * 0.7;
      b -= tempShift * 0.7;
      g -= tintShift * 0.5;
      r += tintShift * 0.25;
      b += tintShift * 0.25;
    }

    // 2. Exposure
    if (adjustments.exposure !== 0) {
      r *= expFactor;
      g *= expFactor;
      b *= expFactor;
    }

    // 3. Contrast around 128
    if (adjustments.contrast !== 0) {
      r = contrastFactor * (r - 128) + 128;
      g = contrastFactor * (g - 128) + 128;
      b = contrastFactor * (b - 128) + 128;
    }

    // Luminance calculation
    let lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    lum = Math.max(0, Math.min(1, lum));

    // 4. Highlights, Shadows, Whites, Blacks recovery
    if (highlightsAdj !== 0 && lum > 0.5) {
      const hWeight = (lum - 0.5) * 2;
      const factor = 1 + highlightsAdj * hWeight * 0.5;
      r *= factor;
      g *= factor;
      b *= factor;
    }
    if (shadowsAdj !== 0 && lum < 0.5) {
      const sWeight = (0.5 - lum) * 2;
      const boost = shadowsAdj * sWeight * 60;
      r += boost;
      g += boost;
      b += boost;
    }
    if (whitesAdj !== 0 && lum > 0.75) {
      const wWeight = (lum - 0.75) * 4;
      const factor = 1 + whitesAdj * wWeight * 0.4;
      r *= factor;
      g *= factor;
      b *= factor;
    }
    if (blacksAdj !== 0 && lum < 0.25) {
      const bWeight = (0.25 - lum) * 4;
      const factor = 1 + blacksAdj * bWeight * 0.4;
      r *= factor;
      g *= factor;
      b *= factor;
    }

    // 5. 3-Way Color Grading Wheels (Shadows, Midtones, Highlights)
    const normLum = Math.max(0, Math.min(1, lum + balanceOffset));
    const shadowWeight = Math.max(0, 1 - normLum * 2);
    const highlightWeight = Math.max(0, (normLum - 0.5) * 2);
    const midtoneWeight = Math.max(
      0,
      1 - Math.abs(normLum - 0.5) * 2
    );

    if (shadowWeight > 0) {
      r += shadowsRgb[0] * shadowWeight;
      g += shadowsRgb[1] * shadowWeight;
      b += shadowsRgb[2] * shadowWeight;
      if (shadowsLum !== 0) {
        const lumAdd = (shadowsLum / 100) * 40 * shadowWeight;
        r += lumAdd;
        g += lumAdd;
        b += lumAdd;
      }
    }
    if (midtoneWeight > 0) {
      r += midtonesRgb[0] * midtoneWeight;
      g += midtonesRgb[1] * midtoneWeight;
      b += midtonesRgb[2] * midtoneWeight;
      if (midtonesLum !== 0) {
        const lumAdd = (midtonesLum / 100) * 40 * midtoneWeight;
        r += lumAdd;
        g += lumAdd;
        b += lumAdd;
      }
    }
    if (highlightWeight > 0) {
      r += highlightsRgb[0] * highlightWeight;
      g += highlightsRgb[1] * highlightWeight;
      b += highlightsRgb[2] * highlightWeight;
      if (highlightsLum !== 0) {
        const lumAdd = (highlightsLum / 100) * 40 * highlightWeight;
        r += lumAdd;
        g += lumAdd;
        b += lumAdd;
      }
    }

    // 6. Tone Curves lookup
    let cr = clamp(Math.round(r));
    let cg = clamp(Math.round(g));
    let cb = clamp(Math.round(b));

    // Per-channel curve
    cr = lutR[cr];
    cg = lutG[cg];
    cb = lutB[cb];

    // Composite RGB curve
    cr = lutRgb[cr];
    cg = lutRgb[cg];
    cb = lutRgb[cb];

    // 7. Vibrance, Saturation & 8-Channel HSL Mixer
    const [hue, sat, light] = rgbToHsl(cr, cg, cb);

    let finalHue = hue;
    let finalSat = sat;
    let finalLight = light;

    // HSL 8-Channel mixer
    const channelWeights = getHslChannelWeights(hue);
    for (const cw of channelWeights) {
      const chVal = hslGrading[cw.channel];
      if (chVal.hue !== 0) {
        finalHue += (chVal.hue / 100) * 30 * cw.weight;
      }
      if (chVal.saturation !== 0) {
        finalSat += (chVal.saturation / 100) * cw.weight * 0.5;
      }
      if (chVal.lightness !== 0) {
        finalLight += (chVal.lightness / 100) * cw.weight * 0.3;
      }
    }

    // Global Saturation & Vibrance
    if (saturationAdj !== 0) {
      finalSat += saturationAdj * 0.6;
    }
    if (vibranceAdj !== 0) {
      // Vibrance selectively boosts lower saturated pixels while protecting high saturated skin tones
      const vibMult = (1 - finalSat) * vibranceAdj * 0.8;
      finalSat += vibMult;
    }

    finalSat = Math.max(0, Math.min(1, finalSat));
    finalLight = Math.max(0, Math.min(1, finalLight));

    const [postR, postG, postB] = hslToRgb(finalHue, finalSat, finalLight);

    // Apply filter intensity blend & selective layer mask weight
    const blendFactor = (filterIntensity / 100) * layerWeight;
    data[i] = clamp(Math.round(origR + (postR - origR) * blendFactor));
    data[i + 1] = clamp(Math.round(origG + (postG - origG) * blendFactor));
    data[i + 2] = clamp(Math.round(origB + (postB - origB) * blendFactor));
  }

  // 8. Vignette effect (if configured)
  if (adjustments.vignette !== 0) {
    applyVignette(data, width, height, adjustments.vignette);
  }

  // 9. Film Grain effect (if configured)
  if (adjustments.grain > 0) {
    applyFilmGrain(data, width, height, adjustments.grain);
  }

  // 10. AI Virtual Studio Spotlight (if enabled)
  if (options.virtualLight?.enabled) {
    applyVirtualStudioLight(data, width, height, options.virtualLight);
  }

  // 11. AI Sky Atmosphere (if preset selected)
  if (options.skyAtmosphere && options.skyAtmosphere.preset !== "none") {
    applySkyAtmosphere(data, width, height, options.skyAtmosphere);
  }

  destCtx.putImageData(imgData, 0, 0);

  // 12. Clarity & Sharpening pass (Convolution filter)
  if (adjustments.clarity !== 0 || adjustments.sharpen > 0) {
    applySharpenAndClarity(destCtx, width, height, adjustments.sharpen, adjustments.clarity);
  }
}

// 13. Virtual Studio Spotlight / Keylight
function applyVirtualStudioLight(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  light: VirtualLight
) {
  if (!light || !light.enabled || light.intensity <= 0) return;

  const lightX = light.x * width;
  const lightY = light.y * height;
  const lightRadius = Math.max(25, (light.radius / 100) * Math.max(width, height) * 0.85);
  const intensity = (light.intensity / 100) * 1.6;

  let tintR = 255;
  let tintG = 240;
  let tintB = 220;

  if (light.color) {
    const hex = light.color.replace("#", "");
    if (hex.length === 6) {
      tintR = parseInt(hex.substring(0, 2), 16);
      tintG = parseInt(hex.substring(2, 4), 16);
      tintB = parseInt(hex.substring(4, 6), 16);
    }
  }

  const warmth = light.warmth;
  tintR = clamp(tintR + warmth * 1.3);
  tintB = clamp(tintB - warmth * 1.3);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * width;
    for (let x = 0; x < width; x++) {
      const idx = (rowOffset + x) * 4;
      const dx = x - lightX;
      const dy = y - lightY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < lightRadius) {
        const t = dist / lightRadius;
        const falloff = (1 - t * t * (3 - 2 * t)) * intensity;

        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];

        data[idx] = clamp(r + (tintR / 255) * 85 * falloff);
        data[idx + 1] = clamp(g + (tintG / 255) * 80 * falloff);
        data[idx + 2] = clamp(b + (tintB / 255) * 75 * falloff);
      }
    }
  }
}

// 14. Sky Atmosphere Harmonizer
function applySkyAtmosphere(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  sky: SkyAtmosphere
) {
  if (!sky || sky.preset === "none" || sky.intensity <= 0) return;

  const horizonY = height * ((100 - sky.horizonBlend * 0.5) / 100);
  const intensity = (sky.intensity / 100) * 0.75;

  let topR = 255, topG = 120, topB = 40;
  let horR = 255, horG = 200, horB = 90;

  switch (sky.preset) {
    case "sunset":
      topR = 190; topG = 60; topB = 140;
      horR = 255; horG = 130; horB = 45;
      break;
    case "golden":
      topR = 240; topG = 160; topB = 50;
      horR = 255; horG = 215; horB = 95;
      break;
    case "azure":
      topR = 20; topG = 90; topB = 210;
      horR = 125; horG = 210; horB = 255;
      break;
    case "starry":
      topR = 15; topG = 18; topB = 45;
      horR = 40; horG = 30; horB = 75;
      break;
    case "dusk":
      topR = 85; topG = 45; topB = 110;
      horR = 230; horG = 110; horB = 80;
      break;
  }

  for (let y = 0; y < horizonY; y++) {
    const skyProgress = y / horizonY;
    const skyAlpha = (1 - Math.pow(skyProgress, 1.4)) * intensity;

    const curR = topR * (1 - skyProgress) + horR * skyProgress;
    const curG = topG * (1 - skyProgress) + horG * skyProgress;
    const curB = topB * (1 - skyProgress) + horB * skyProgress;

    const rowOffset = y * width;
    for (let x = 0; x < width; x++) {
      const idx = (rowOffset + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;

      const skyWeight = skyAlpha * (0.35 + lum * 0.65);

      data[idx] = clamp(r * (1 - skyWeight) + curR * skyWeight);
      data[idx + 1] = clamp(g * (1 - skyWeight) + curG * skyWeight);
      data[idx + 2] = clamp(b * (1 - skyWeight) + curB * skyWeight);
    }
  }
}

// Apply smooth radial vignette
function applyVignette(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  amount: number // -100 to 100
) {
  const cx = width / 2;
  const cy = height / 2;
  const maxDist = Math.sqrt(cx * cx + cy * cy);
  const factor = amount / 100;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy) / maxDist;

      // Smooth falloff beyond midpoint 0.35
      if (dist > 0.35) {
        const falloff = Math.pow((dist - 0.35) / 0.65, 2);
        const vignette = 1 - factor * falloff;
        data[idx] = clamp(data[idx] * vignette);
        data[idx + 1] = clamp(data[idx + 1] * vignette);
        data[idx + 2] = clamp(data[idx + 2] * vignette);
      }
    }
  }
}

// Monochromatic natural photographic grain
function applyFilmGrain(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  amount: number // 0 to 100
) {
  const intensity = (amount / 100) * 35;
  const len = data.length;

  for (let i = 0; i < len; i += 4) {
    // Generate organic noise
    const noise = (Math.random() - 0.5) * intensity;
    data[i] = clamp(data[i] + noise);
    data[i + 1] = clamp(data[i + 1] + noise);
    data[i + 2] = clamp(data[i + 2] + noise);
  }
}

// Local Clarity & Sharpening convolution
function applySharpenAndClarity(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  sharpenAmount: number,
  clarityAmount: number
) {
  if (sharpenAmount <= 0 && clarityAmount === 0) return;

  const imgData = ctx.getImageData(0, 0, width, height);
  const src = imgData.data;
  const output = ctx.createImageData(width, height);
  const dst = output.data;

  // Pre-copy alpha
  for (let i = 0; i < src.length; i += 4) {
    dst[i + 3] = src[i + 3];
  }

  const sWeight = (sharpenAmount / 100) * 0.7;
  const cWeight = (clarityAmount / 100) * 0.4;
  const totalWeight = sWeight + cWeight;

  if (totalWeight <= 0) return;

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = (y * width + x) * 4;

      for (let c = 0; c < 3; c++) {
        const center = src[idx + c];
        const up = src[((y - 1) * width + x) * 4 + c];
        const down = src[((y + 1) * width + x) * 4 + c];
        const left = src[(y * width + (x - 1)) * 4 + c];
        const right = src[(y * width + (x + 1)) * 4 + c];

        const laplacian = 4 * center - up - down - left - right;
        dst[idx + c] = clamp(center + laplacian * totalWeight * 0.35);
      }
    }
  }

  // Copy edge pixels safely
  for (let x = 0; x < width; x++) {
    const topIdx = x * 4;
    const botIdx = ((height - 1) * width + x) * 4;
    for (let c = 0; c < 3; c++) {
      dst[topIdx + c] = src[topIdx + c];
      dst[botIdx + c] = src[botIdx + c];
    }
  }
  for (let y = 0; y < height; y++) {
    const leftIdx = y * width * 4;
    const rightIdx = (y * width + (width - 1)) * 4;
    for (let c = 0; c < 3; c++) {
      dst[leftIdx + c] = src[leftIdx + c];
      dst[rightIdx + c] = src[rightIdx + c];
    }
  }

  ctx.putImageData(output, 0, 0);
}

// Compute 256-bin RGB and Luminance Histogram
export interface HistogramData {
  r: number[];
  g: number[];
  b: number[];
  lum: number[];
  shadowClipping: boolean;
  highlightClipping: boolean;
}

export function calculateHistogram(canvas: HTMLCanvasElement): HistogramData {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  const result: HistogramData = {
    r: new Array(256).fill(0),
    g: new Array(256).fill(0),
    b: new Array(256).fill(0),
    lum: new Array(256).fill(0),
    shadowClipping: false,
    highlightClipping: false,
  };

  if (!ctx) return result;

  // Downsample to fast 200x200 sample for instant responsive FPS
  const sampleW = Math.min(200, canvas.width);
  const sampleH = Math.min(200, canvas.height);

  const sampleCanvas = document.createElement("canvas");
  sampleCanvas.width = sampleW;
  sampleCanvas.height = sampleH;
  const sampleCtx = sampleCanvas.getContext("2d", { willReadFrequently: true });
  if (!sampleCtx) return result;

  sampleCtx.drawImage(canvas, 0, 0, sampleW, sampleH);
  const data = sampleCtx.getImageData(0, 0, sampleW, sampleH).data;
  const len = data.length;

  let shadowClipCount = 0;
  let highlightClipCount = 0;

  for (let i = 0; i < len; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const lum = Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b);

    result.r[r]++;
    result.g[g]++;
    result.b[b]++;
    result.lum[lum]++;

    if (lum <= 2) shadowClipCount++;
    if (lum >= 253) highlightClipCount++;
  }

  const totalPixels = sampleW * sampleH;
  result.shadowClipping = shadowClipCount / totalPixels > 0.02;
  result.highlightClipping = highlightClipCount / totalPixels > 0.02;

  return result;
}
