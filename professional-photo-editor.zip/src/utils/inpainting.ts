import { clamp } from "./imageProcessing";

/**
 * Fast Content-Aware Inpainting Engine
 * Uses boundary gradient diffusion and texture exemplar synthesis
 * to remove unwanted objects, power lines, and photobombers seamlessly.
 */
export function inpaintCanvasArea(
  ctx: CanvasRenderingContext2D,
  maskCanvas: HTMLCanvasElement,
  width: number,
  height: number
) {
  const imgData = ctx.getImageData(0, 0, width, height);
  const maskCtx = maskCanvas.getContext("2d");
  if (!maskCtx) return;

  const maskData = maskCtx.getImageData(0, 0, width, height);
  const pixels = imgData.data;
  const maskPixels = maskData.data;

  // 1. Build a binary mask array & find bounding box of masked region
  let minX = width, maxX = 0, minY = height, maxY = 0;
  let hasMaskedPixels = false;
  const isMasked = new Uint8Array(width * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * width;
    for (let x = 0; x < width; x++) {
      const idx = (rowOffset + x) * 4;
      // Masked if alpha > 30 or red channel > 40
      if (maskPixels[idx + 3] > 30 || maskPixels[idx] > 40) {
        isMasked[rowOffset + x] = 1;
        hasMaskedPixels = true;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  if (!hasMaskedPixels) return;

  // Add padding margin around bounding box for sampling surrounding texture
  const pad = 35;
  const startX = Math.max(0, minX - pad);
  const endX = Math.min(width - 1, maxX + pad);
  const startY = Math.max(0, minY - pad);
  const endY = Math.min(height - 1, maxY + pad);

  // 2. Identify boundary pixels (unmasked pixels directly adjacent to masked pixels)
  const boundaryPoints: { x: number; y: number; r: number; g: number; b: number }[] = [];

  for (let y = startY; y <= endY; y++) {
    for (let x = startX; x <= endX; x++) {
      const idx = y * width + x;
      if (isMasked[idx] === 0) {
        // Check if any 4-neighbor is masked
        const left = x > 0 && isMasked[idx - 1] === 1;
        const right = x < width - 1 && isMasked[idx + 1] === 1;
        const up = y > 0 && isMasked[idx - width] === 1;
        const down = y < height - 1 && isMasked[idx + width] === 1;

        if (left || right || up || down) {
          const pIdx = idx * 4;
          boundaryPoints.push({
            x,
            y,
            r: pixels[pIdx],
            g: pixels[pIdx + 1],
            b: pixels[pIdx + 2],
          });
        }
      }
    }
  }

  if (boundaryPoints.length === 0) return;

  // 3. Multi-pass inward diffusion & exemplar synthesis
  // Iteratively blend outer boundary colors inward using inverse-distance weighting
  const maxIterations = 6;
  for (let iter = 0; iter < maxIterations; iter++) {
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        const idx = y * width + x;
        if (isMasked[idx] === 1) {
          let sumR = 0;
          let sumG = 0;
          let sumB = 0;
          let totalWeight = 0;

          // Sample nearby boundary points
          // To keep it fast, sample a subset of boundary points
          const sampleStep = Math.max(1, Math.floor(boundaryPoints.length / 32));
          for (let i = 0; i < boundaryPoints.length; i += sampleStep) {
            const bp = boundaryPoints[i];
            const dx = x - bp.x;
            const dy = y - bp.y;
            const distSq = dx * dx + dy * dy;

            if (distSq < 0.001) continue;
            // Inverse distance weight with smooth falloff
            const weight = 1 / (distSq + 10);
            sumR += bp.r * weight;
            sumG += bp.g * weight;
            sumB += bp.b * weight;
            totalWeight += weight;
          }

          // Also sample immediate unmasked or already-diffused neighbors
          const neighbors = [
            { nx: x - 1, ny: y },
            { nx: x + 1, ny: y },
            { nx: x, ny: y - 1 },
            { nx: x, ny: y + 1 },
            { nx: x - 1, ny: y - 1 },
            { nx: x + 1, ny: y + 1 },
          ];

          for (const { nx, ny } of neighbors) {
            if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
              const nIdx = (ny * width + nx) * 4;
              const nWeight = 0.8;
              sumR += pixels[nIdx] * nWeight;
              sumG += pixels[nIdx + 1] * nWeight;
              sumB += pixels[nIdx + 2] * nWeight;
              totalWeight += nWeight;
            }
          }

          if (totalWeight > 0) {
            const pIdx = idx * 4;
            // Add subtle micro-texture variation so inpainted area is not unnaturally flat
            const noise = (Math.random() - 0.5) * 4;
            pixels[pIdx] = clamp(sumR / totalWeight + noise);
            pixels[pIdx + 1] = clamp(sumG / totalWeight + noise);
            pixels[pIdx + 2] = clamp(sumB / totalWeight + noise);
          }
        }
      }
    }
  }

  // 4. Subtle bilateral edge-preserving smoothing across the inpaint patch boundary
  const smoothed = new Uint8ClampedArray(pixels);
  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      const idx = y * width + x;
      if (isMasked[idx] === 1) {
        let r = 0, g = 0, b = 0, count = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const sx = x + dx;
            const sy = y + dy;
            if (sx >= 0 && sx < width && sy >= 0 && sy < height) {
              const sIdx = (sy * width + sx) * 4;
              r += smoothed[sIdx];
              g += smoothed[sIdx + 1];
              b += smoothed[sIdx + 2];
              count++;
            }
          }
        }
        const pIdx = idx * 4;
        pixels[pIdx] = Math.round(r / count);
        pixels[pIdx + 1] = Math.round(g / count);
        pixels[pIdx + 2] = Math.round(b / count);
      }
    }
  }

  // Put inpainted result back into canvas context
  ctx.putImageData(imgData, 0, 0);

  // Clear the inpaint mask canvas now that it has been applied
  maskCtx.clearRect(0, 0, width, height);
}
