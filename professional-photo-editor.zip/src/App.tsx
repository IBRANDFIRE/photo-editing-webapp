import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  ActiveTab,
  Adjustments,
  AiMaskState,
  ColorGrading,
  CropState,
  DEFAULT_ADJUSTMENTS,
  DEFAULT_COLOR_GRADING,
  DEFAULT_CROP,
  DEFAULT_CURVES,
  DEFAULT_HSL_GRADING,
  DEFAULT_SKY_ATMOSPHERE,
  DEFAULT_VIRTUAL_LIGHT,
  EditState,
  ExportSettings,
  FilterPreset,
  HslGrading,
  RetouchStroke,
  RetouchTool,
  SkyAtmosphere,
  ToneCurves,
  VirtualLight,
} from "./types";
import { SAMPLE_IMAGES, SampleImage } from "./constants/sampleImages";
import {
  applyImagePipeline,
  calculateHistogram,
  HistogramData,
} from "./utils/imageProcessing";
import {
  applyAllRetouchStrokes,
  applyRetouchStroke,
} from "./utils/retouchEngine";
import { inpaintCanvasArea } from "./utils/inpainting";
import {
  createMaskFromPolygon,
  generateLocalSaliencyMask,
  renderBackgroundReplacement,
} from "./utils/segmentation";
import { HeaderBar } from "./components/HeaderBar";
import { Histogram } from "./components/Histogram";
import { AdjustmentsPanel } from "./components/AdjustmentsPanel";
import { ColorWheelsEditor } from "./components/ColorWheelsEditor";
import { ToneCurveEditor } from "./components/ToneCurveEditor";
import { HslEditor } from "./components/HslEditor";
import { FiltersPanel } from "./components/FiltersPanel";
import { RetouchToolbar } from "./components/RetouchToolbar";
import { AiStudioPanel } from "./components/AiStudioPanel";
import { CropRotatePanel } from "./components/CropRotatePanel";
import { BeforeAfterSlider } from "./components/BeforeAfterSlider";
import { ExportModal } from "./components/ExportModal";
import {
  SlidersHorizontal,
  CircleDot,
  Spline,
  Palette,
  Sparkles,
  Bandage,
  Wand2,
  Crop,
  ZoomIn,
  ZoomOut,
  Maximize,
} from "lucide-react";

export default function App() {
  // Loaded original Image & Canvas elements
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageDimensions, setImageDimensions] = useState({ width: 1200, height: 800 });

  const originalImgRef = useRef<HTMLImageElement | null>(null);
  const originalCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const displayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const viewportContainerRef = useRef<HTMLDivElement | null>(null);

  // Core Edit State
  const initialEditState: EditState = {
    adjustments: { ...DEFAULT_ADJUSTMENTS },
    colorGrading: { ...DEFAULT_COLOR_GRADING },
    hsl: { ...DEFAULT_HSL_GRADING },
    curves: { ...DEFAULT_CURVES },
    activeFilterId: null,
    filterIntensity: 100,
    crop: { ...DEFAULT_CROP },
    retouchStrokes: [],
    virtualLight: { ...DEFAULT_VIRTUAL_LIGHT },
    skyAtmosphere: { ...DEFAULT_SKY_ATMOSPHERE },
  };

  const [editState, setEditState] = useState<EditState>(initialEditState);

  // Undo / Redo Stack
  const [history, setHistory] = useState<EditState[]>([initialEditState]);
  const [historyIdx, setHistoryIdx] = useState(0);

  // Active Tool Tab
  const [activeTab, setActiveTab] = useState<ActiveTab>("adjust");

  // Retouch Brush settings
  const [retouchTool, setRetouchTool] = useState<RetouchTool>("eraser");
  const [brushSize, setBrushSize] = useState<number>(36);
  const [brushOpacity, setBrushOpacity] = useState<number>(0.75);
  const [isBrushing, setIsBrushing] = useState(false);
  const [cloneSourcePoint, setCloneSourcePoint] = useState<{ x: number; y: number } | null>(null);
  const currentStrokeRef = useRef<{ x: number; y: number }[]>([]);
  const [cursorPos, setCursorPos] = useState<{ x: number; y: number } | null>(null);

  // AI Mask & Background State
  const [aiMaskState, setAiMaskState] = useState<AiMaskState>({
    hasSubjectMask: false,
    maskCanvas: null,
    targetLayer: "all",
    backgroundMode: "keep",
    solidBgColor: "#ffffff",
    bgBlurRadius: 16,
  });
  const [showMaskOverlay, setShowMaskOverlay] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiStatusMessage, setAiStatusMessage] = useState("");

  // Live Viewport and Histogram
  const [isCompareActive, setIsCompareActive] = useState(false);
  const [isHistogramVisible, setIsHistogramVisible] = useState(true);
  const [histogramData, setHistogramData] = useState<HistogramData>({
    r: new Array(256).fill(0),
    g: new Array(256).fill(0),
    b: new Array(256).fill(0),
    lum: new Array(256).fill(0),
    shadowClipping: false,
    highlightClipping: false,
  });

  // Zoom & Pan
  const [zoomLevel, setZoomLevel] = useState(1);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });

  // Export Modal
  const [exportModalOpen, setExportModalOpen] = useState(false);

  // Helper to push history state
  const pushHistory = useCallback((newState: EditState) => {
    setHistory((prev) => {
      const sliced = prev.slice(0, historyIdx + 1);
      return [...sliced, newState];
    });
    setHistoryIdx((prev) => prev + 1);
  }, [historyIdx]);

  // Load an image source into original canvas
  const loadImageSource = (src: string) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      originalImgRef.current = img;
      setImageDimensions({ width: img.naturalWidth, height: img.naturalHeight });

      // Build original canvas
      const origCanvas = document.createElement("canvas");
      origCanvas.width = img.naturalWidth;
      origCanvas.height = img.naturalHeight;
      const ctx = origCanvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(img, 0, 0);
      }
      originalCanvasRef.current = origCanvas;

      // Reset edit state
      setEditState(initialEditState);
      setHistory([initialEditState]);
      setHistoryIdx(0);
      setAiMaskState({
        hasSubjectMask: false,
        maskCanvas: null,
        targetLayer: "all",
        backgroundMode: "keep",
        solidBgColor: "#ffffff",
        bgBlurRadius: 16,
      });

      setImageLoaded(true);
    };
    img.src = src;
  };

  // Initial load with first demo sample
  useEffect(() => {
    loadImageSource(SAMPLE_IMAGES[0].url);
  }, []);

  // Main Render Pipeline Execution
  const renderPipeline = useCallback(() => {
    if (!originalCanvasRef.current || !displayCanvasRef.current) return;

    const source = originalCanvasRef.current;
    const dest = displayCanvasRef.current;

    // 1. Offscreen canvas for color & adjustments
    const gradingCanvas = document.createElement("canvas");
    gradingCanvas.width = source.width;
    gradingCanvas.height = source.height;

    applyImagePipeline(source, gradingCanvas, {
      adjustments: editState.adjustments,
      colorGrading: editState.colorGrading,
      hsl: editState.hsl,
      curves: editState.curves,
      filterIntensity: editState.filterIntensity,
      maskCanvas: aiMaskState.maskCanvas,
      targetMaskLayer: aiMaskState.targetLayer,
      virtualLight: editState.virtualLight,
      skyAtmosphere: editState.skyAtmosphere,
    });

    // 2. Apply Retouch Strokes
    if (editState.retouchStrokes.length > 0) {
      const gCtx = gradingCanvas.getContext("2d");
      if (gCtx) {
        applyAllRetouchStrokes(
          gCtx,
          editState.retouchStrokes,
          source.width,
          source.height
        );
      }
    }

    // 3. Background Replacement (transparent cutout, solid color, bokeh blur)
    let finalCanvas = gradingCanvas;
    if (
      aiMaskState.hasSubjectMask &&
      aiMaskState.maskCanvas &&
      aiMaskState.backgroundMode !== "keep"
    ) {
      const bgCanvas = document.createElement("canvas");
      renderBackgroundReplacement(
        gradingCanvas,
        aiMaskState.maskCanvas,
        bgCanvas,
        aiMaskState.backgroundMode,
        aiMaskState.solidBgColor,
        aiMaskState.bgBlurRadius
      );
      finalCanvas = bgCanvas;
    }

    // 4. Crop, Rotation & Straighten Transform
    dest.width = source.width;
    dest.height = source.height;
    const destCtx = dest.getContext("2d");
    if (!destCtx) return;

    destCtx.save();
    destCtx.clearRect(0, 0, dest.width, dest.height);

    const cx = dest.width / 2;
    const cy = dest.height / 2;
    destCtx.translate(cx, cy);

    // Apply rotation + fine straighten
    const totalRotation =
      ((editState.crop.rotation + editState.crop.straighten) * Math.PI) / 180;
    destCtx.rotate(totalRotation);

    // Flips
    destCtx.scale(
      editState.crop.flipH ? -1 : 1,
      editState.crop.flipV ? -1 : 1
    );

    destCtx.drawImage(finalCanvas, -cx, -cy);
    destCtx.restore();

    // 5. Subject Mask Overlay (ruby red translucent highlight if enabled)
    if (showMaskOverlay && aiMaskState.maskCanvas) {
      destCtx.save();
      const tempOverlay = document.createElement("canvas");
      tempOverlay.width = source.width;
      tempOverlay.height = source.height;
      const tCtx = tempOverlay.getContext("2d");
      if (tCtx) {
        tCtx.drawImage(aiMaskState.maskCanvas, 0, 0);
        tCtx.globalCompositeOperation = "source-in";
        tCtx.fillStyle = "rgba(239, 68, 68, 0.4)";
        tCtx.fillRect(0, 0, tempOverlay.width, tempOverlay.height);
      }
      destCtx.drawImage(tempOverlay, 0, 0);
      destCtx.restore();
    }

    // Update live histogram
    const hist = calculateHistogram(dest);
    setHistogramData(hist);
  }, [editState, aiMaskState, showMaskOverlay]);

  // Run render pipeline whenever state updates
  useEffect(() => {
    if (imageLoaded) {
      renderPipeline();
    }
  }, [imageLoaded, renderPipeline]);

  // Undo / Redo
  const handleUndo = () => {
    if (historyIdx > 0) {
      const targetIdx = historyIdx - 1;
      setHistoryIdx(targetIdx);
      setEditState(history[targetIdx]);
    }
  };

  const handleRedo = () => {
    if (historyIdx < history.length - 1) {
      const targetIdx = historyIdx + 1;
      setHistoryIdx(targetIdx);
      setEditState(history[targetIdx]);
    }
  };

  // Quick Reset All
  const handleResetAll = () => {
    setEditState(initialEditState);
    pushHistory(initialEditState);
  };

  // Adjustments update handler
  const handleAdjustmentsChange = (newAdj: Adjustments) => {
    const updated = { ...editState, adjustments: newAdj };
    setEditState(updated);
    pushHistory(updated);
  };

  // Color Grading update handler
  const handleColorGradingChange = (newGrading: ColorGrading) => {
    const updated = { ...editState, colorGrading: newGrading };
    setEditState(updated);
    pushHistory(updated);
  };

  // Curves update handler
  const handleCurvesChange = (newCurves: ToneCurves) => {
    const updated = { ...editState, curves: newCurves };
    setEditState(updated);
    pushHistory(updated);
  };

  // HSL update handler
  const handleHslChange = (newHsl: HslGrading) => {
    const updated = { ...editState, hsl: newHsl };
    setEditState(updated);
    pushHistory(updated);
  };

  // Filter Selection handler
  const handleSelectFilter = (filter: FilterPreset | null) => {
    if (!filter) {
      const updated: EditState = {
        ...editState,
        activeFilterId: null,
      };
      setEditState(updated);
      pushHistory(updated);
      return;
    }

    const updated: EditState = {
      ...editState,
      activeFilterId: filter.id,
      adjustments: {
        ...editState.adjustments,
        ...(filter.adjustments || {}),
      },
      colorGrading: {
        ...editState.colorGrading,
        ...(filter.colorGrading || {}),
      },
      hsl: {
        ...editState.hsl,
        ...(filter.hsl || {}),
      },
      curves: {
        ...editState.curves,
        ...(filter.curves || {}),
      },
    };
    setEditState(updated);
    pushHistory(updated);
  };

  // Crop & Rotate update handler
  const handleCropChange = (newCrop: CropState) => {
    const updated = { ...editState, crop: newCrop };
    setEditState(updated);
    pushHistory(updated);
  };

  // Interactive Retouching Canvas handlers
  const getCanvasCoords = (clientX: number, clientY: number) => {
    if (!displayCanvasRef.current) return null;
    const canvas = displayCanvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  };

  const handleCanvasPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (activeTab !== "retouch") return;
    e.preventDefault();
    (e.target as Element).setPointerCapture?.(e.pointerId);

    const coords = getCanvasCoords(e.clientX, e.clientY);
    if (!coords) return;

    // In clone mode, Alt-click or first click sets the clone source pin
    if (retouchTool === "clone" && (e.altKey || !cloneSourcePoint)) {
      setCloneSourcePoint(coords);
      return;
    }

    setIsBrushing(true);
    currentStrokeRef.current = [coords];

    // Real-time stroke feedback
    if (displayCanvasRef.current) {
      const ctx = displayCanvasRef.current.getContext("2d");
      if (ctx) {
        applyRetouchStroke(
          ctx,
          {
            id: `temp-${Date.now()}`,
            tool: retouchTool,
            points: [coords],
            size: brushSize,
            feather: 0.5,
            opacity: brushOpacity,
            sourcePoint: retouchTool === "clone" ? (cloneSourcePoint || coords) : undefined,
          },
          displayCanvasRef.current.width,
          displayCanvasRef.current.height
        );
      }
    }
  };

  const handleCanvasPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const coords = getCanvasCoords(e.clientX, e.clientY);
    if (coords) {
      setCursorPos({ x: e.clientX, y: e.clientY });
    }

    if (!isBrushing || activeTab !== "retouch" || !coords) return;

    currentStrokeRef.current.push(coords);

    if (displayCanvasRef.current) {
      const ctx = displayCanvasRef.current.getContext("2d");
      if (ctx) {
        applyRetouchStroke(
          ctx,
          {
            id: `temp-${Date.now()}`,
            tool: retouchTool,
            points: [coords],
            size: brushSize,
            feather: 0.5,
            opacity: brushOpacity,
            sourcePoint: retouchTool === "clone" ? (cloneSourcePoint || coords) : undefined,
          },
          displayCanvasRef.current.width,
          displayCanvasRef.current.height
        );
      }
    }
  };

  const handleCanvasPointerUp = () => {
    if (!isBrushing || activeTab !== "retouch") return;
    setIsBrushing(false);

    if (currentStrokeRef.current.length > 0) {
      const newStroke: RetouchStroke = {
        id: `stroke-${Date.now()}`,
        tool: retouchTool,
        points: [...currentStrokeRef.current],
        size: brushSize,
        feather: 0.5,
        opacity: brushOpacity,
        sourcePoint: retouchTool === "clone" ? (cloneSourcePoint || currentStrokeRef.current[0]) : undefined,
      };

      const updated = {
        ...editState,
        retouchStrokes: [...editState.retouchStrokes, newStroke],
      };
      setEditState(updated);
      pushHistory(updated);
      currentStrokeRef.current = [];
    }
  };

  const handleUndoRetouch = () => {
    if (editState.retouchStrokes.length > 0) {
      const updatedStrokes = editState.retouchStrokes.slice(0, -1);
      const updated = { ...editState, retouchStrokes: updatedStrokes };
      setEditState(updated);
      pushHistory(updated);
    }
  };

  const handleClearRetouch = () => {
    const updated = { ...editState, retouchStrokes: [] };
    setEditState(updated);
    pushHistory(updated);
  };

  // Content-Aware AI Inpaint: removes objects masked by eraser brush
  const handleApplyInpaint = () => {
    if (!displayCanvasRef.current || !originalCanvasRef.current) return;
    const canvas = displayCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const eraserStrokes = editState.retouchStrokes.filter((s) => s.tool === "eraser");
    if (eraserStrokes.length === 0) return;

    // Create mask from eraser strokes
    const maskCanvas = document.createElement("canvas");
    maskCanvas.width = canvas.width;
    maskCanvas.height = canvas.height;
    const mCtx = maskCanvas.getContext("2d");
    if (!mCtx) return;

    mCtx.fillStyle = "#ffffff";
    mCtx.strokeStyle = "#ffffff";
    for (const stroke of eraserStrokes) {
      mCtx.beginPath();
      for (let i = 0; i < stroke.points.length; i++) {
        const pt = stroke.points[i];
        if (i === 0) mCtx.moveTo(pt.x, pt.y);
        else mCtx.lineTo(pt.x, pt.y);
      }
      mCtx.lineWidth = stroke.size;
      mCtx.lineCap = "round";
      mCtx.lineJoin = "round";
      mCtx.stroke();
    }

    // Run multi-pass inpainting engine
    inpaintCanvasArea(ctx, maskCanvas, canvas.width, canvas.height);

    // Also apply to base original canvas so subsequent renders maintain the object removal
    const origCtx = originalCanvasRef.current.getContext("2d");
    if (origCtx) {
      origCtx.drawImage(canvas, 0, 0);
    }

    // Filter out applied eraser strokes and commit state
    const nonEraserStrokes = editState.retouchStrokes.filter((s) => s.tool !== "eraser");
    const updated = { ...editState, retouchStrokes: nonEraserStrokes };
    setEditState(updated);
    pushHistory(updated);
  };

  // Virtual Light updates
  const handleUpdateVirtualLight = (partial: Partial<VirtualLight>) => {
    const updated = {
      ...editState,
      virtualLight: { ...editState.virtualLight, ...partial },
    };
    setEditState(updated);
    pushHistory(updated);
  };

  // Sky Atmosphere updates
  const handleUpdateSkyAtmosphere = (partial: Partial<SkyAtmosphere>) => {
    const updated = {
      ...editState,
      skyAtmosphere: { ...editState.skyAtmosphere, ...partial },
    };
    setEditState(updated);
    pushHistory(updated);
  };

  // AI Feature 1: Smart Image Enhancement
  const handleSmartEnhance = async (): Promise<string | undefined> => {
    if (!displayCanvasRef.current) return;
    try {
      setIsAiLoading(true);
      setAiStatusMessage("Analyzing dynamic range & color spectrum...");

      const dataUrl = displayCanvasRef.current.toDataURL("image/jpeg", 0.85);

      const res = await fetch("/api/ai/smart-enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: dataUrl }),
      });

      if (!res.ok) throw new Error("Enhancement server call failed");
      const data = await res.json();

      if (data.adjustments) {
        const updated: EditState = {
          ...editState,
          adjustments: {
            ...editState.adjustments,
            ...data.adjustments,
          },
        };
        setEditState(updated);
        pushHistory(updated);
      }

      return data.analysis || "Enhanced exposure and color tone fidelity.";
    } catch (err) {
      console.warn("AI Enhance failed, applying professional tone heuristic:", err);
      // Fallback pro heuristic
      const heuristic: Partial<Adjustments> = {
        exposure: 0.15,
        contrast: 12,
        highlights: -20,
        shadows: 25,
        whites: 5,
        blacks: -8,
        vibrance: 15,
        clarity: 10,
        texture: 8,
      };
      const updated: EditState = {
        ...editState,
        adjustments: { ...editState.adjustments, ...heuristic },
      };
      setEditState(updated);
      pushHistory(updated);
      return "Auto-balanced dynamic range: opened shadows, protected highlights, and enhanced clarity.";
    } finally {
      setIsAiLoading(false);
      setAiStatusMessage("");
    }
  };

  // AI Feature 2: Subject Masking & Detection
  const handleDetectSubject = async () => {
    if (!displayCanvasRef.current || !originalCanvasRef.current) return;
    try {
      setIsAiLoading(true);
      setAiStatusMessage("Locating subject boundaries & contours...");

      const sourceCanvas = originalCanvasRef.current;
      const dataUrl = sourceCanvas.toDataURL("image/jpeg", 0.85);

      const res = await fetch("/api/ai/detect-subject", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: dataUrl }),
      });

      let maskCanvas: HTMLCanvasElement;
      if (res.ok) {
        const data = await res.json();
        maskCanvas = createMaskFromPolygon(
          sourceCanvas.width,
          sourceCanvas.height,
          data.polygon,
          data.boxes
        );
      } else {
        // Fallback local saliency mask
        maskCanvas = generateLocalSaliencyMask(sourceCanvas);
      }

      setAiMaskState((prev) => ({
        ...prev,
        hasSubjectMask: true,
        maskCanvas,
        targetLayer: "subject",
      }));
      setShowMaskOverlay(true);
      setTimeout(() => setShowMaskOverlay(false), 2000);
    } catch (err) {
      console.warn("AI detect subject fallback:", err);
      if (originalCanvasRef.current) {
        const maskCanvas = generateLocalSaliencyMask(originalCanvasRef.current);
        setAiMaskState((prev) => ({
          ...prev,
          hasSubjectMask: true,
          maskCanvas,
          targetLayer: "subject",
        }));
        setShowMaskOverlay(true);
        setTimeout(() => setShowMaskOverlay(false), 2000);
      }
    } finally {
      setIsAiLoading(false);
      setAiStatusMessage("");
    }
  };

  // AI Subject Preset shortcuts
  const handleApplySubjectPreset = (type: "pop-subject" | "dim-background") => {
    if (type === "pop-subject") {
      setAiMaskState((prev) => ({ ...prev, targetLayer: "subject" }));
      const updated: EditState = {
        ...editState,
        adjustments: {
          ...editState.adjustments,
          exposure: (editState.adjustments.exposure || 0) + 0.35,
          clarity: (editState.adjustments.clarity || 0) + 20,
          texture: (editState.adjustments.texture || 0) + 15,
        },
      };
      setEditState(updated);
      pushHistory(updated);
    } else if (type === "dim-background") {
      setAiMaskState((prev) => ({ ...prev, targetLayer: "background" }));
      const updated: EditState = {
        ...editState,
        adjustments: {
          ...editState.adjustments,
          exposure: (editState.adjustments.exposure || 0) - 0.45,
          contrast: (editState.adjustments.contrast || 0) - 10,
          vignette: (editState.adjustments.vignette || 0) + 25,
        },
      };
      setEditState(updated);
      pushHistory(updated);
    }
  };

  const handleResetMask = () => {
    setAiMaskState({
      hasSubjectMask: false,
      maskCanvas: null,
      targetLayer: "all",
      backgroundMode: "keep",
      solidBgColor: "#ffffff",
      bgBlurRadius: 16,
    });
    setShowMaskOverlay(false);
  };

  // High-Resolution Export Execution
  const handleExportDownload = async (settings: ExportSettings) => {
    if (!originalImgRef.current) return;

    const img = originalImgRef.current;
    const exportScale = settings.scale;
    const targetW = Math.round(img.naturalWidth * exportScale);
    const targetH = Math.round(img.naturalHeight * exportScale);

    // Render offscreen canvas at full native resolution
    const fullSourceCanvas = document.createElement("canvas");
    fullSourceCanvas.width = targetW;
    fullSourceCanvas.height = targetH;
    const fCtx = fullSourceCanvas.getContext("2d");
    if (!fCtx) return;

    fCtx.drawImage(img, 0, 0, targetW, targetH);

    // Apply exact same master pipeline at full resolution
    const fullGradingCanvas = document.createElement("canvas");
    applyImagePipeline(fullSourceCanvas, fullGradingCanvas, {
      adjustments: editState.adjustments,
      colorGrading: editState.colorGrading,
      hsl: editState.hsl,
      curves: editState.curves,
      filterIntensity: editState.filterIntensity,
    });

    // Retouch strokes scaled
    if (editState.retouchStrokes.length > 0) {
      const origW = img.naturalWidth;
      const scaleFactor = targetW / origW;
      const scaledStrokes: RetouchStroke[] = editState.retouchStrokes.map((s) => ({
        ...s,
        size: s.size * scaleFactor,
        points: s.points.map((p) => ({
          x: p.x * scaleFactor,
          y: p.y * scaleFactor,
        })),
      }));

      const gCtx = fullGradingCanvas.getContext("2d");
      if (gCtx) {
        applyAllRetouchStrokes(gCtx, scaledStrokes, targetW, targetH);
      }
    }

    // Background replacement scaled
    let exportCanvas = fullGradingCanvas;
    if (
      aiMaskState.hasSubjectMask &&
      aiMaskState.maskCanvas &&
      aiMaskState.backgroundMode !== "keep"
    ) {
      const scaledMask = document.createElement("canvas");
      scaledMask.width = targetW;
      scaledMask.height = targetH;
      const smCtx = scaledMask.getContext("2d");
      if (smCtx) {
        smCtx.drawImage(aiMaskState.maskCanvas, 0, 0, targetW, targetH);
      }

      const bgExportCanvas = document.createElement("canvas");
      renderBackgroundReplacement(
        fullGradingCanvas,
        scaledMask,
        bgExportCanvas,
        aiMaskState.backgroundMode,
        aiMaskState.solidBgColor,
        aiMaskState.bgBlurRadius * exportScale
      );
      exportCanvas = bgExportCanvas;
    }

    // Geometry transforms
    const finalExportCanvas = document.createElement("canvas");
    finalExportCanvas.width = targetW;
    finalExportCanvas.height = targetH;
    const finalCtx = finalExportCanvas.getContext("2d");
    if (!finalCtx) return;

    finalCtx.save();
    const cx = targetW / 2;
    const cy = targetH / 2;
    finalCtx.translate(cx, cy);
    const totalRotation =
      ((editState.crop.rotation + editState.crop.straighten) * Math.PI) / 180;
    finalCtx.rotate(totalRotation);
    finalCtx.scale(
      editState.crop.flipH ? -1 : 1,
      editState.crop.flipV ? -1 : 1
    );
    finalCtx.drawImage(exportCanvas, -cx, -cy);
    finalCtx.restore();

    // Optional Watermark
    if (settings.watermark && settings.watermarkText) {
      finalCtx.save();
      finalCtx.font = `600 ${Math.max(16, targetW * 0.02)}px sans-serif`;
      finalCtx.fillStyle = "rgba(255, 255, 255, 0.75)";
      finalCtx.shadowColor = "rgba(0, 0, 0, 0.6)";
      finalCtx.shadowBlur = 8;
      const padding = targetW * 0.03;
      finalCtx.textAlign = "right";
      finalCtx.fillText(settings.watermarkText, targetW - padding, targetH - padding);
      finalCtx.restore();
    }

    // Output blob & trigger download
    const mimeType = `image/${settings.format}`;
    const qualityParam = settings.format === "png" ? undefined : settings.quality / 100;

    finalExportCanvas.toBlob(
      (blob) => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${settings.filename || "photo-export"}.${settings.format}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      },
      mimeType,
      qualityParam
    );
  };

  // Copy to clipboard
  const handleCopyToClipboard = async (settings: ExportSettings): Promise<boolean> => {
    if (!displayCanvasRef.current) return false;
    try {
      const blob = await new Promise<Blob | null>((resolve) => {
        displayCanvasRef.current?.toBlob((b) => resolve(b), "image/png");
      });
      if (blob && navigator.clipboard?.write) {
        await navigator.clipboard.write([
          new ClipboardItem({ "image/png": blob }),
        ]);
        return true;
      }
      return false;
    } catch (err) {
      console.error("Clipboard copy failed:", err);
      return false;
    }
  };

  // Handle local file drop or upload
  const handleUploadFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (typeof e.target?.result === "string") {
        loadImageSource(e.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Navigation tabs configuration
  const tabs: { id: ActiveTab; label: string; icon: any }[] = [
    { id: "adjust", label: "Light", icon: SlidersHorizontal },
    { id: "color", label: "Color Wheels", icon: CircleDot },
    { id: "curves", label: "Curves", icon: Spline },
    { id: "hsl", label: "HSL", icon: Palette },
    { id: "filters", label: "Filters", icon: Sparkles },
    { id: "retouch", label: "Retouch", icon: Bandage },
    { id: "ai", label: "AI Studio", icon: Wand2 },
    { id: "crop", label: "Geometry", icon: Crop },
  ];

  return (
    <div className="flex flex-col h-screen w-screen bg-zinc-950 text-zinc-100 overflow-hidden select-none font-sans antialiased">
      {/* 1. Header Bar */}
      <HeaderBar
        canUndo={historyIdx > 0}
        canRedo={historyIdx < history.length - 1}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onResetAll={handleResetAll}
        isCompareActive={isCompareActive}
        onToggleCompare={() => setIsCompareActive(!isCompareActive)}
        isHistogramVisible={isHistogramVisible}
        onToggleHistogram={() => setIsHistogramVisible(!isHistogramVisible)}
        onSelectSample={(sample) => loadImageSource(sample.url)}
        onUploadFile={handleUploadFile}
        onOpenExport={() => setExportModalOpen(true)}
      />

      {/* 2. Main Studio Workstation Layout */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        {/* Center Viewport Stage */}
        <div
          ref={viewportContainerRef}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            if (e.dataTransfer.files?.[0]) {
              handleUploadFile(e.dataTransfer.files[0]);
            }
          }}
          className="flex-1 relative bg-zinc-950 flex items-center justify-center p-3 sm:p-6 overflow-hidden"
        >
          {/* Subtle checkered backdrop for transparency inspection */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage:
                "radial-gradient(#3f3f46 1px, transparent 1px), radial-gradient(#3f3f46 1px, #09090b 1px)",
              backgroundSize: "24px 24px",
              backgroundPosition: "0 0, 12px 12px",
            }}
          />

          {/* Before / After Split Slider Mode */}
          {isCompareActive ? (
            <BeforeAfterSlider
              originalCanvas={originalCanvasRef.current}
              editedCanvas={displayCanvasRef.current}
              className="w-full h-full max-w-4xl max-h-[85vh] shadow-2xl"
            />
          ) : (
            /* Standard Live Canvas Viewport */
            <div
              className="relative max-w-full max-h-full flex items-center justify-center transition-transform duration-100"
              style={{
                transform: `scale(${zoomLevel}) translate(${panOffset.x}px, ${panOffset.y}px)`,
              }}
            >
              <canvas
                ref={displayCanvasRef}
                onPointerDown={handleCanvasPointerDown}
                onPointerMove={handleCanvasPointerMove}
                onPointerUp={handleCanvasPointerUp}
                className={`max-h-[80vh] max-w-full object-contain rounded-xl shadow-2xl transition-shadow ${
                  activeTab === "retouch"
                    ? "cursor-crosshair active:shadow-sky-500/20"
                    : "cursor-default"
                }`}
                style={{
                  aspectRatio: `${imageDimensions.width} / ${imageDimensions.height}`,
                }}
              />

              {/* Retouch Live Brush Ring Cursor */}
              {activeTab === "retouch" && cursorPos && (
                <div
                  className={`fixed pointer-events-none rounded-full border-2 shadow-lg -translate-x-1/2 -translate-y-1/2 z-40 transition-colors ${
                    retouchTool === "eraser"
                      ? "border-red-400 bg-red-500/20 shadow-red-500/30"
                      : retouchTool === "clone"
                      ? "border-amber-400 bg-amber-500/20 shadow-amber-500/30"
                      : retouchTool === "redeye"
                      ? "border-rose-400 bg-rose-500/20"
                      : retouchTool === "splash"
                      ? "border-sky-400 bg-sky-500/20"
                      : "border-white/90 bg-white/10"
                  }`}
                  style={{
                    left: `${cursorPos.x}px`,
                    top: `${cursorPos.y}px`,
                    width: `${brushSize}px`,
                    height: `${brushSize}px`,
                  }}
                />
              )}
            </div>
          )}

          {/* Floating Live Histogram Overlay */}
          {isHistogramVisible && (
            <div className="absolute top-4 left-4 z-20 w-64 shadow-2xl animate-fadeIn">
              <Histogram data={histogramData} />
            </div>
          )}

          {/* Floating Zoom & Pan Controls */}
          <div className="absolute bottom-4 left-4 z-20 flex items-center gap-1 bg-zinc-900/90 backdrop-blur-md p-1 rounded-xl border border-zinc-800 text-xs shadow-xl">
            <button
              type="button"
              onClick={() => setZoomLevel((z) => Math.max(0.5, z - 0.25))}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              title="Zoom out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono text-[10px] text-zinc-400 px-1">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoomLevel((z) => Math.min(3, z + 0.25))}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              title="Zoom in"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setZoomLevel(1);
                setPanOffset({ x: 0, y: 0 });
              }}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition ml-0.5"
              title="Reset Zoom"
            >
              <Maximize className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right / Desktop Sidebar & Mobile Bottom Sheet */}
        <aside className="w-full md:w-[380px] lg:w-[420px] bg-zinc-950/95 border-t md:border-t-0 md:border-l border-zinc-800/80 flex flex-col z-20 shrink-0 h-[45vh] md:h-full overflow-hidden shadow-2xl">
          {/* Desktop Tabs Header */}
          <div className="hidden md:flex items-center gap-1 overflow-x-auto p-2 bg-zinc-900/80 border-b border-zinc-800/80 scrollbar-none text-xs">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isSelected = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl font-semibold whitespace-nowrap transition ${
                    isSelected
                      ? "bg-zinc-800 text-white shadow-xs"
                      : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 text-sky-400" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Active Tool Sub-Panel Body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {activeTab === "adjust" && (
              <AdjustmentsPanel
                adjustments={editState.adjustments}
                onChange={handleAdjustmentsChange}
              />
            )}

            {activeTab === "color" && (
              <ColorWheelsEditor
                colorGrading={editState.colorGrading}
                onChange={handleColorGradingChange}
              />
            )}

            {activeTab === "curves" && (
              <ToneCurveEditor
                curves={editState.curves}
                onChange={handleCurvesChange}
              />
            )}

            {activeTab === "hsl" && (
              <HslEditor hsl={editState.hsl} onChange={handleHslChange} />
            )}

            {activeTab === "filters" && (
              <FiltersPanel
                activeFilterId={editState.activeFilterId}
                filterIntensity={editState.filterIntensity}
                onSelectFilter={handleSelectFilter}
                onIntensityChange={(val) => {
                  const updated = { ...editState, filterIntensity: val };
                  setEditState(updated);
                  pushHistory(updated);
                }}
              />
            )}

            {activeTab === "retouch" && (
              <RetouchToolbar
                activeTool={retouchTool}
                brushSize={brushSize}
                brushOpacity={brushOpacity}
                strokesCount={editState.retouchStrokes.length}
                cloneSourcePoint={cloneSourcePoint}
                onSelectTool={setRetouchTool}
                onSizeChange={setBrushSize}
                onOpacityChange={setBrushOpacity}
                onUndoStroke={handleUndoRetouch}
                onClearStrokes={handleClearRetouch}
                onApplyInpaint={handleApplyInpaint}
              />
            )}

            {activeTab === "ai" && (
              <AiStudioPanel
                currentImageDataUrl={
                  displayCanvasRef.current?.toDataURL("image/jpeg", 0.8) || ""
                }
                aiMaskState={aiMaskState}
                showMaskOverlay={showMaskOverlay}
                virtualLight={editState.virtualLight}
                skyAtmosphere={editState.skyAtmosphere}
                onToggleMaskOverlay={() => setShowMaskOverlay(!showMaskOverlay)}
                onDetectSubject={handleDetectSubject}
                onSmartEnhance={handleSmartEnhance}
                onUpdateAiMaskState={(partial) =>
                  setAiMaskState((prev) => ({ ...prev, ...partial }))
                }
                onApplySubjectPreset={handleApplySubjectPreset}
                onResetMask={handleResetMask}
                onUpdateVirtualLight={handleUpdateVirtualLight}
                onUpdateSkyAtmosphere={handleUpdateSkyAtmosphere}
                isAiLoading={isAiLoading}
                aiStatusMessage={aiStatusMessage}
              />
            )}

            {activeTab === "crop" && (
              <CropRotatePanel
                crop={editState.crop}
                onChange={handleCropChange}
              />
            )}
          </div>

          {/* Mobile Bottom Dock Tabs */}
          <div className="md:hidden flex items-center justify-around bg-zinc-900 border-t border-zinc-800 p-1 shrink-0 overflow-x-auto scrollbar-none">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isSelected = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex flex-col items-center gap-0.5 p-2 rounded-xl transition min-w-[52px] ${
                    isSelected ? "text-sky-400 font-semibold" : "text-zinc-400"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-[9px] truncate max-w-full">
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
        </aside>
      </div>

      {/* High-Resolution Export Modal */}
      <ExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
        originalDimensions={imageDimensions}
        onExportDownload={handleExportDownload}
        onCopyToClipboard={handleCopyToClipboard}
      />
    </div>
  );
}
